import datetime
from data.users import user_data


class UserService:

    @staticmethod
    def fetch_user(user_id: str) -> dict:
        """
        Fetch user data from in-memory dataset
        """
        try:
            user = user_data[user_id]
            return user
        except KeyError:
            return {
                "error": "User not found",
                "user_id": user_id
            }
        except Exception as e:
            return {
                "error": str(e),
                "user_id": user_id
            }

    # ---------------------------
    # Derived User Computations
    # ---------------------------

    @staticmethod
    def calculate_age(date_of_birth: str) -> int:
        """
        Calculate age from date_of_birth (YYYY-MM-DD)
        """
        dob = datetime.datetime.strptime(date_of_birth, "%Y-%m-%d").date()
        today = datetime.date.today()
        return today.year - dob.year - (
            (today.month, today.day) < (dob.month, dob.day)
        )

    @staticmethod
    def get_active_policies(user: dict) -> list:
        """
        Return list of active policies
        """
        policies = user.get("policies", [])
        return [p for p in policies if p.get("policy_status") == "Active"]

    @staticmethod
    def get_expiring_policies(user: dict, days: int = 30) -> list:
        """
        Return policies expiring within given number of days
        """
        expiring = []
        active_policies = UserService.get_active_policies(user)
        today = datetime.date.today()

        for policy in active_policies:
            end_date_str = policy.get("policy_end_date")
            if not end_date_str:
                continue

            end_date = datetime.datetime.strptime(end_date_str, "%Y-%m-%d").date()
            days_left = (end_date - today).days

            if 0 <= days_left <= days:
                policy["days_to_expiry"] = days_left
                expiring.append(policy)

        return expiring

    @staticmethod
    def get_active_policy_categories(user: dict) -> list:
        """
        Return list of active policy categories (Health, Life, etc.)
        """
        active_policies = UserService.get_active_policies(user)
        categories = []

        for policy in active_policies:
            policy_type = policy.get("policy_type")
            if policy_type:
                categories.append(policy_type)

        return categories

    @staticmethod
    def build_user_context(user: dict) -> dict:
        """
        Build structured user context for recommendation engine
        """
        personal = user.get("personal_details", {})
        financial = user.get("financial_details", {})
        health = user.get("health_profile", {})

        age = UserService.calculate_age(personal.get("date_of_birth"))

        return {
            "user_id": user.get("user_id"),
            "age": age,
            "city": personal.get("address", {}).get("city"),
            "state": personal.get("address", {}).get("state"),
            "country": personal.get("address", {}).get("country"),
            "occupation": financial.get("income_details", {}).get("occupation"),
            "annual_income": financial.get("income_details", {}).get("annual_income"),
            "smoker": health.get("smoker"),
            "pre_existing_conditions": health.get("pre_existing_conditions", []),
            "active_policies": UserService.get_active_policies(user),
            "expiring_policies": UserService.get_expiring_policies(user),
            "active_categories": UserService.get_active_policy_categories(user)
        }
