from langchain.tools import tool
from services.news_service import NewsService

@tool
def fetch_location_news(location: str):
    """Fetch latest news related to user's location"""
    return NewsService.fetch_news(location)
