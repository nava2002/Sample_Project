from langchain.tools import tool
from services.user_service import UserService
# Simulated DB


@tool
def fetch_user_data(user_id: str) -> dict:
    """Fetch user insurance profile data"""
    user = UserService.fetch_user(user_id)
    return user
