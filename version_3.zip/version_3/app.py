from fastapi import FastAPI, HTTPException
from agents.policy_agent import generate_recommendation

app = FastAPI()


@app.post("/recommend-policy/{user_id}")
def recommend_policy(user_id: str):
    try:
        result = generate_recommendation(user_id)

        if "error" in result:
            # Include raw LLM response if available
            detail_msg = result.get("raw_response", result["error"])
            raise HTTPException(status_code=400, detail=detail_msg)

        return {
            "user_id": user_id,
            "recommendation": result
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
