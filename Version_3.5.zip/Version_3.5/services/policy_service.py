import json
from typing import List, Dict
from datetime import datetime, timedelta


class PolicyService:

    # -----------------------------------
    # Load All Policies
    # -----------------------------------

    @staticmethod
    def fetch_policies() -> List[Dict]:
        """
        Load all policy entities from policies.json
        """
        try:
            with open("data/policies.json", "r") as f:
                return json.load(f)
        except Exception as e:
            return {"error": str(e)}

    # -----------------------------------
    # Entity Separation Helpers
    # -----------------------------------

    @staticmethod
    def get_products(policies: list) -> List[Dict]:
        return [p for p in policies if p.get("entityType") == "Product"]

    @staticmethod
    def get_schemes(policies: list) -> List[Dict]:
        return [p for p in policies if p.get("entityType") == "Scheme"]

    @staticmethod
    def get_riders(policies: list) -> List[Dict]:
        return [p for p in policies if p.get("entityType") == "Rider"]

    @staticmethod
    def get_offers(policies: list) -> List[Dict]:
        return [p for p in policies if p.get("entityType") == "Offer"]

    # -----------------------------------
    # Active Policy Helpers
    # -----------------------------------

    @staticmethod
    def get_active_policy_ids(user_context: dict) -> List[str]:
        """
        Extract active policy IDs from user context
        """
        user_policies = user_context.get("policies", [])
        return [p.get("policy_id") for p in user_policies]

    @staticmethod
    def get_expiring_policies(user_context: dict, days: int = 30) -> List[str]:
        """
        Detect policies expiring within given number of days
        """
        expiring_ids = []
        user_policies = user_context.get("policies", [])

        today = datetime.today()
        threshold = today + timedelta(days=days)

        for policy in user_policies:
            expiry_date_str = policy.get("expiry_date")

            if expiry_date_str:
                try:
                    expiry_date = datetime.strptime(
                        expiry_date_str, "%Y-%m-%d"
                    )
                    if expiry_date <= threshold:
                        expiring_ids.append(policy.get("policy_id"))
                except Exception:
                    pass

        return expiring_ids

    # -----------------------------------
    # Deterministic Eligibility Filtering
    # -----------------------------------

    @staticmethod
    def filter_eligible_schemes(user_context: dict, schemes: list) -> List[Dict]:
        """
        Apply deterministic eligibility filtering based on scheme rules
        """
        eligible = []

        user_age = user_context.get("age")
        occupation = user_context.get("occupation")

        for scheme in schemes:
            rules = scheme.get("eligibilityRules", {})
            is_eligible = True

            # Age eligibility
            min_age = rules.get("minEntryAge")
            max_age = rules.get("maxEntryAge")

            if min_age is not None and user_age < min_age:
                is_eligible = False

            if max_age is not None and user_age > max_age:
                is_eligible = False

            # Occupation eligibility
            allowed_occupations = rules.get("allowedOccupations")
            if allowed_occupations:
                if occupation not in allowed_occupations:
                    is_eligible = False

            # Vehicle rules (if exists but no vehicle info → mark ineligible)
            vehicle_age_max = rules.get("vehicleAgeMaxYears")
            allowed_vehicle_types = rules.get("allowedVehicleTypes")

            if vehicle_age_max or allowed_vehicle_types:
                is_eligible = False

            if is_eligible:
                eligible.append(scheme)

        return eligible

    # -----------------------------------
    # Scheme to Product Mapping
    # -----------------------------------

    @staticmethod
    def attach_product_info(
        eligible_schemes: list,
        products: list
    ) -> List[Dict]:
        """
        Attach product metadata to eligible schemes
        """
        product_map = {p["productId"]: p for p in products}
        enriched = []

        for scheme in eligible_schemes:
            product_id = scheme.get("productId")
            product_info = product_map.get(product_id, {})

            combined = {
                "schemeId": scheme.get("schemeId"),
                "schemeName": scheme.get("schemeName"),
                "productId": product_id,
                "productName": product_info.get("productName"),
                "category": product_info.get("category"),
                "description": product_info.get("description"),
                "eligibilityRules": scheme.get("eligibilityRules"),
                "coverageOptions": scheme.get("coverageOptions"),
            }

            enriched.append(combined)

        return enriched
