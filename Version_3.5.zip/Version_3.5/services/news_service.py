import json
from typing import Dict, List
import random  # new import for slight randomness

class NewsService:

    @staticmethod
    def fetch_news() -> List[Dict]:
        """
        Load all news articles from news.json
        """
        try:
            with open("data/news.json", "r") as f:
                return json.load(f)
        except Exception as e:
            return {"error": str(e)}

    # ----------------------------------------
    # Risk Signal Extraction Engine
    # ----------------------------------------
    @staticmethod
    def extract_risk_signals(user_context: dict, news_articles: List[Dict]) -> Dict:
        """
        Convert raw news into structured risk signals
        """

        user_country = (user_context.get("country") or "").lower()
        user_state = (user_context.get("state") or "").lower()

        risk_signals = {
            "flood_risk": False,
            "wildfire_risk": False,
            "health_risk_trend": False,
            "cyber_risk": False,
            "matched_articles": []
        }

        for article in news_articles:

            countries = [c.lower() for c in article.get("country", [])]
            categories = [c.lower() for c in article.get("category", [])]
            keywords = [k.lower() for k in article.get("keywords", [])]
            sentiment_stats = article.get("sentiment_stats", {})
            negative_score = sentiment_stats.get("negative", 0)

            # Only consider high negative sentiment (>60%)
            if negative_score < 60:
                continue

            # Region match check
            region_match = (
                user_country in countries or
                "global" in countries or
                user_country == ""
            )

            if not region_match:
                continue

            # Flood detection
            if "flood" in keywords or "rainfall" in keywords:
                risk_signals["flood_risk"] = True
                risk_signals["matched_articles"].append(article["title"])

            # Wildfire detection
            if "wildfire" in keywords:
                risk_signals["wildfire_risk"] = True
                risk_signals["matched_articles"].append(article["title"])

            # Health trend detection
            if "health" in categories and "insurance" in categories:
                # add slight randomness for variety
                risk_signals["health_risk_trend"] = random.choice([True, True, False])
                risk_signals["matched_articles"].append(article["title"])

            # Cyber risk detection
            if "cybersecurity" in keywords or "ransomware" in keywords:
                risk_signals["cyber_risk"] = True
                risk_signals["matched_articles"].append(article["title"])

        # If nothing detected, randomly boost one for variability
        if not any([risk_signals["flood_risk"], risk_signals["wildfire_risk"],
                    risk_signals["health_risk_trend"], risk_signals["cyber_risk"]]):
            choice = random.choice(["flood_risk", "wildfire_risk", "health_risk_trend"])
            risk_signals[choice] = True

        return risk_signals

    # ----------------------------------------
    # Map Risk to Product Category Boost
    # ----------------------------------------
    @staticmethod
    def map_risk_to_category_boost(risk_signals: Dict) -> Dict:
        """
        Convert risk signals into product category score boosts
        """

        boosts = {
            "Property": 0,
            "Health": 0,
            "Life": 0,
            "Motor": 0,
            "Travel": 0,
            "Accident": 0,
            "Specialty": 0
        }

        if risk_signals.get("flood_risk"):
            boosts["Property"] += random.randint(20, 30)  # slight variation

        if risk_signals.get("wildfire_risk"):
            boosts["Property"] += random.randint(15, 25)

        if risk_signals.get("health_risk_trend"):
            boosts["Health"] += random.randint(10, 20)

        if risk_signals.get("cyber_risk"):
            boosts["Specialty"] += random.randint(10, 20)

        # Always ensure minimal boost for all categories
        for cat in boosts:
            if boosts[cat] == 0:
                boosts[cat] = random.randint(5, 10)

        return boosts
