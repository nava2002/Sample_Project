user_data ={
    "USR102938":{"user_id": "USR102938",
  "personal_details": {
    "first_name": "Joseph",
    "last_name": "Pauly",
    "date_of_birth": "1995-06-14",
    "marital_status": "UnMarried",
    "nationality": "Amarican",
    "aadhaar_number": "XXXX-XXXX-4587",
    "pan_number": "ABCDE1234F",
    "contact_details": {
      "email": "joseph.pauly@email.com",
      "phone": "+91-9876543210"
    },
    "address": {
      "street": "MG Road",
      "city": "Kochi",
      "state": "Kerala",
      "pincode": "682016",
      "country": "India"
    },
    "kyc_status": "Verified",
    "created_at": "2025-03-11T10:30:00Z"
  },
  "policies": [
    {
      "policy_id": "POL556677",
      "policy_type": "Health Insurance",
      "plan_name": "Family Health Plus",
      "sum_insured": 1000000,
      "premium_amount": 15000,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-04-01",
      "policy_end_date": "2026-03-31",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Anjali Nair",
          "relationship": "Spouse",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM90012",
          "claim_type": "Hospitalization",
          "claim_amount": 45000,
          "claim_status": "Approved",
          "claim_date": "2025-08-14",
          "hospital_name": "Aster Medcity"
        }
      ]
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 900000,
      "occupation": "Software Engineer",
      "employer": "Infosys Ltd",
      "employment_type": "Salaried"
    },
    "payment_details": {
      "payment_method": "UPI",
      "last_payment_date": "2025-04-01",
      "next_due_date": "2026-04-01",
      "auto_debit_enabled": True
    }
  },
  "health_profile": {
    "height_cm": 175,
    "weight_kg": 78,
    "smoker": False,
    "alcohol_consumption": "Occasional",
    "pre_existing_conditions": [
      "Hypertension"
    ],
    "family_medical_history": [
      "Sugar"
    ]
  },
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Aadhaar Card",
      "file_url": "https://storage.insurance.com/docs/aadhaar_usr102938.pdf",
      "uploaded_at": "2025-03-11"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": False
    },
    "data_consent": {
      "marketing_consent": False,
      "data_processing_consent": True
    }
  }
},
"USR102939": {
    "user_id": "USR102939",
    "personal_details": {
        "first_name": "Ravi",
        "last_name": "Kumar",
        "date_of_birth": "1988-11-23",
        "marital_status": "UnMarried",
        "nationality": "Indian",
        "aadhaar_number": "XXXX-XXXX-1122",
        "pan_number": "ZZZZZ1122X",
        "contact_details": {
            "email": "ravi.kumar@email.com",
            "phone": "+91-9123456780"
        },
        "address": {
            "street": "Near Central Bus Stand",
            "city": "Bangalore",
            "state": "Karnataka",
            "pincode": "560001",
            "country": "India"
        },
        "kyc_status": "Pending",
        "created_at": "2025-05-01T09:00:00Z"
    },
    "policies": [],
    "financial_details": {
        "income_details": {
            "annual_income": 0,
            "occupation": "Unemployed",
            "employer": None,
            "employment_type": None
        },
        "payment_details": {
            "payment_method": None,
            "last_payment_date": None,
            "next_due_date": None,
            "auto_debit_enabled": False
        }
    },
    "health_profile": {
        "height_cm": 168,
        "weight_kg": 60,
        "smoker": True,
        "alcohol_consumption": "Frequent",
        "pre_existing_conditions": [
            "Malnutrition"
        ],
        "family_medical_history": []
    },
    "documents": [],
    "preferences": {
        "communication_preferences": {
            "email_notifications": False,
            "sms_notifications": False,
            "whatsapp_notifications": False
        },
        "data_consent": {
            "marketing_consent": False,
            "data_processing_consent": False
        }
    }
}
,
    "USR200001":{
  "user_id": "USR200001",
  "personal_details": {
    "first_name": "Emma",
    "last_name": "Watson",
    "date_of_birth": "1992-02-10",
    "marital_status": "UnMarried",
    "nationality": "British",
    "passport_number": "UK9988776",
    "contact_details": {
      "email": "emma.watson@email.co.uk",
      "phone": "+44-7700123456"
    },
    "address": {
      "street": "221B Baker Street",
      "city": "London",
      "state": "England",
      "pincode": "NW16XE",
      "country": "UK"
    },
    "kyc_status": "Verified",
    "created_at": "2025-05-10T09:15:00Z"
  },
  "policies": [
    {
      "policy_id": "POL900101",
      "policy_type": "Health Insurance",
      "plan_name": "UK Health Shield Premium",
      "sum_insured": 500000,
      "premium_amount": 2200,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-06-01",
      "policy_end_date": "2026-05-31",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "David Watson",
          "relationship": "Father",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM100345",
          "claim_type": "Outpatient Treatment",
          "claim_amount": 650,
          "claim_status": "Approved",
          "claim_date": "2025-11-12",
          "hospital_name": "Bupa Cromwell Hospital"
        }
      ]
    },
    {
      "policy_id": "POL900102",
      "policy_type": "Life Insurance",
      "plan_name": "Young Professional Term Cover",
      "sum_insured": 750000,
      "premium_amount": 1200,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-07-01",
      "policy_end_date": "2055-06-30",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "David Watson",
          "relationship": "Father",
          "percentage_share": 50
        },
        {
          "name": "Sophia Watson",
          "relationship": "Mother",
          "percentage_share": 50
        }
      ],
      "claims": []
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 65000,
      "occupation": "Marketing Manager",
      "employer": "Unilever UK",
      "employment_type": "Salaried"
    },
    "payment_details": {
      "payment_method": "Credit Card",
      "last_payment_date": "2025-07-01",
      "next_due_date": "2026-07-01",
      "auto_debit_enabled": True
    },
    "investment_profile": {
      "risk_appetite": "Moderate",
      "existing_investments": [
        "Mutual Funds",
        "Stocks",
        "Retirement Pension Plan"
      ]
    }
  },
  "health_profile": {
    "height_cm": 168,
    "weight_kg": 62,
    "smoker": False,
    "alcohol_consumption": "Occasional",
    "exercise_frequency": "3_times_per_week",
    "pre_existing_conditions": [],
    "family_medical_history": [
      "Breast Cancer"
    ]
  },
  "lifestyle_profile": {
    "travel_frequency": "Moderate",
    "hobbies": [
      "Yoga",
      "Reading",
      "Travel Blogging"
    ],
    "work_style": "Hybrid"
  },
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Passport",
      "file_url": "https://storage.insurance.com/docs/passport_usr200001.pdf",
      "uploaded_at": "2025-05-10"
    },
    {
      "document_type": "Income Proof",
      "document_name": "Salary Slip",
      "file_url": "https://storage.insurance.com/docs/salary_usr200001.pdf",
      "uploaded_at": "2025-05-11"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": False,
      "whatsapp_notifications": True
    },
    "data_consent": {
      "marketing_consent": True,
      "data_processing_consent": True
    },
    "insurance_preferences": {
      "preferred_policy_types": [
        "Health",
        "Life",
        "Critical Illness",
        "Travel Insurance"
      ],
      "coverage_priority": "Comprehensive"
    }
  },
  "risk_profile": {
    "risk_score": 32,
    "risk_category": "Low",
    "risk_factors": [
      "Family cancer history",
      "Urban sedentary job"
    ]
  }
}
    ,
    "USR200002":{
  "user_id": "USR200002",
  "personal_details": {
    "first_name": "Liam",
    "last_name": "Turner",
    "date_of_birth": "1990-11-22",
    "marital_status": "UnMarried",
    "nationality": "Canadian",
    "sin_number": "XXX-XXX-782",
    "contact_details": {
      "email": "liam.turner@email.ca",
      "phone": "+1-4165552211"
    },
    "address": {
      "street": "45 King Street West",
      "city": "Toronto",
      "state": "Ontario",
      "pincode": "M5H1J8",
      "country": "Canada"
    },
    "kyc_status": "Verified",
    "created_at": "2025-04-20T14:10:00Z"
  },
  "policies": [
    {
      "policy_id": "POL910201",
      "policy_type": "Health Insurance",
      "plan_name": "Maple Health Extended Cover",
      "sum_insured": 400000,
      "premium_amount": 1800,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-05-01",
      "policy_end_date": "2026-04-30",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Grace Turner",
          "relationship": "Mother",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM210567",
          "claim_type": "Dental Treatment",
          "claim_amount": 900,
          "claim_status": "Approved",
          "claim_date": "2025-09-10",
          "hospital_name": "Toronto Dental Care"
        }
      ]
    },
    {
      "policy_id": "POL910202",
      "policy_type": "Life Insurance",
      "plan_name": "Secure Future Term Plan",
      "sum_insured": 600000,
      "premium_amount": 1500,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-06-01",
      "policy_end_date": "2055-05-31",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Grace Turner",
          "relationship": "Mother",
          "percentage_share": 60
        },
        {
          "name": "Robert Turner",
          "relationship": "Father",
          "percentage_share": 40
        }
      ],
      "claims": []
    },
    {
      "policy_id": "POL910203",
      "policy_type": "Vehicle Insurance",
      "plan_name": "Comprehensive Auto Protect",
      "sum_insured": 35000,
      "premium_amount": 1200,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-03-01",
      "policy_end_date": "2026-02-28",
      "policy_status": "Active",
      "insured_asset": {
        "vehicle_type": "Car",
        "make_model": "Toyota Camry 2022",
        "registration_number": "ON-LT-4521"
      },
      "claims": [
        {
          "claim_id": "CLM210890",
          "claim_type": "Accidental Damage",
          "claim_amount": 3200,
          "claim_status": "Settled",
          "claim_date": "2025-07-18"
        }
      ]
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 82000,
      "occupation": "Civil Engineer",
      "employer": "AECOM Canada",
      "employment_type": "Salaried"
    },
    "payment_details": {
      "payment_method": "Bank Transfer",
      "last_payment_date": "2025-06-01",
      "next_due_date": "2026-06-01",
      "auto_debit_enabled": True
    },
    "investment_profile": {
      "risk_appetite": "Moderate",
      "existing_investments": [
        "ETF Portfolio",
        "Retirement Savings Plan (RRSP)",
        "Stocks"
      ]
    },
    "liabilities": {
      "active_loans": [
        {
          "loan_type": "Car Loan",
          "outstanding_amount": 18000,
          "monthly_emi": 520
        }
      ]
    }
  },
  "health_profile": {
    "height_cm": 180,
    "weight_kg": 85,
    "smoker": True,
    "alcohol_consumption": "Moderate",
    "exercise_frequency": "1_time_per_week",
    "pre_existing_conditions": [
      "Asthma"
    ],
    "family_medical_history": [
      "Heart Disease"
    ]
  },
  "lifestyle_profile": {
    "travel_frequency": "Low",
    "hobbies": [
      "Ice Hockey",
      "Camping",
      "Gaming"
    ],
    "vehicle_owner": True,
    "work_style": "Onsite"
  },
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Driver License",
      "file_url": "https://storage.insurance.com/docs/license_usr200002.pdf",
      "uploaded_at": "2025-04-21"
    },
    {
      "document_type": "Income Proof",
      "document_name": "Tax Return",
      "file_url": "https://storage.insurance.com/docs/tax_usr200002.pdf",
      "uploaded_at": "2025-04-22"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": False
    },
    "data_consent": {
      "marketing_consent": True,
      "data_processing_consent": True
    },
    "insurance_preferences": {
      "preferred_policy_types": [
        "Health",
        "Vehicle",
        "Life",
        "Disability Insurance"
      ],
      "coverage_priority": "Balanced"
    }
  },
  "risk_profile": {
    "risk_score": 58,
    "risk_category": "Medium",
    "risk_factors": [
      "Smoking habit",
      "Pre-existing asthma",
      "Family cardiac history",
      "Vehicle ownership"
    ]
  }
}
,
"USR200003":{
  "user_id": "USR200003",
  "family_type": "Couple_No_Children",
  "personal_details": {
    "primary_holder": {
      "first_name": "Noah",
      "last_name": "Smith",
      "date_of_birth": "1988-05-14",
      "gender": "Male",
      "nationality": "Australian"
    },
    "spouse_details": {
      "first_name": "Olivia",
      "last_name": "Smith",
      "date_of_birth": "1990-08-20",
      "gender": "Female",
      "nationality": "Australian"
    },
    "marital_status": "Married",
    "contact_details": {
      "email": "noah.smith@email.au",
      "phone": "+61-410223344"
    },
    "address": {
      "street": "18 Harbour View Drive",
      "city": "Sydney",
      "state": "New South Wales",
      "pincode": "2000",
      "country": "Australia"
    },
    "kyc_status": "Verified",
    "created_at": "2025-02-15T08:45:00Z"
  },
  "policies": [
    {
      "policy_id": "POL920301",
      "policy_type": "Family Health Insurance",
      "plan_name": "Aussie Family Floater Gold",
      "covered_members": [
        "Noah Smith",
        "Olivia Smith"
      ],
      "sum_insured": 800000,
      "premium_amount": 3200,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-03-01",
      "policy_end_date": "2026-02-28",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Ethan Smith",
          "relationship": "Brother",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM310455",
          "claim_type": "Hospitalization",
          "claim_amount": 5400,
          "claim_status": "Approved",
          "claim_date": "2025-10-05",
          "hospital_name": "Sydney Adventist Hospital",
          "patient_name": "Olivia Smith"
        }
      ]
    },
    {
      "policy_id": "POL920302",
      "policy_type": "Life Insurance",
      "plan_name": "Joint Term Protection Plan",
      "sum_insured": 1200000,
      "premium_amount": 2800,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-04-01",
      "policy_end_date": "2055-03-31",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Olivia Smith",
          "relationship": "Spouse",
          "percentage_share": 100
        }
      ],
      "secondary_nominee": {
        "name": "Noah Smith",
        "relationship": "Spouse"
      },
      "claims": []
    },
    {
      "policy_id": "POL920303",
      "policy_type": "Home Insurance",
      "plan_name": "Comprehensive Home Shield",
      "sum_insured": 650000,
      "premium_amount": 1400,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-01-15",
      "policy_end_date": "2026-01-14",
      "policy_status": "Active",
      "insured_asset": {
        "property_type": "Apartment",
        "ownership_type": "Owned",
        "property_value": 900000,
        "location_risk": "Moderate Flood Risk"
      },
      "claims": []
    }
  ],
  "financial_details": {
    "income_details": {
      "primary_income": {
        "name": "Noah Smith",
        "occupation": "Software Architect",
        "employer": "Atlassian",
        "annual_income": 135000,
        "employment_type": "Salaried"
      },
      "spouse_income": {
        "name": "Olivia Smith",
        "occupation": "Interior Designer",
        "employer": "Freelance",
        "annual_income": 72000,
        "employment_type": "Self Employed"
      },
      "combined_income": 207000
    },
    "payment_details": {
      "payment_method": "Joint Bank Account",
      "last_payment_date": "2025-04-01",
      "next_due_date": "2026-04-01",
      "auto_debit_enabled": True
    },
    "investment_profile": {
      "risk_appetite": "Moderate to High",
      "existing_investments": [
        "Australian Superannuation Fund",
        "ETF Portfolio",
        "Real Estate Investment Trust (REIT)"
      ]
    },
    "liabilities": {
      "active_loans": [
        {
          "loan_type": "Home Loan",
          "outstanding_amount": 520000,
          "monthly_emi": 2800
        }
      ]
    }
  },
  "health_profile": {
    "members_health": [
      {
        "name": "Noah Smith",
        "height_cm": 178,
        "weight_kg": 82,
        "smoker": False,
        "alcohol_consumption": "Occasional",
        "exercise_frequency": "2_times_per_week",
        "pre_existing_conditions": []
      },
      {
        "name": "Olivia Smith",
        "height_cm": 165,
        "weight_kg": 60,
        "smoker": False,
        "alcohol_consumption": "Rare",
        "exercise_frequency": "4_times_per_week",
        "pre_existing_conditions": [
          "Thyroid"
        ]
      }
    ],
    "family_medical_history": [
      "Diabetes",
      "Hypertension"
    ]
  },
  "lifestyle_profile": {
    "travel_frequency": "Moderate",
    "travel_type": "Leisure International Travel",
    "hobbies": [
      "Surfing",
      "Photography",
      "Interior Decorating",
      "Road Trips"
    ],
    "home_owner": True,
    "vehicle_owner": True
  },
  "assets": [
    {
      "asset_type": "Car",
      "make_model": "Mazda CX-5 2023",
      "estimated_value": 42000
    },
    {
      "asset_type": "Residential Property",
      "estimated_value": 900000
    }
  ],
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Passport - Noah",
      "file_url": "https://storage.insurance.com/docs/passport_noah_usr200003.pdf",
      "uploaded_at": "2025-02-15"
    },
    {
      "document_type": "KYC",
      "document_name": "Passport - Olivia",
      "file_url": "https://storage.insurance.com/docs/passport_olivia_usr200003.pdf",
      "uploaded_at": "2025-02-15"
    },
    {
      "document_type": "Property Document",
      "document_name": "Apartment Ownership Certificate",
      "file_url": "https://storage.insurance.com/docs/property_usr200003.pdf",
      "uploaded_at": "2025-02-16"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": True
    },
    "data_consent": {
      "marketing_consent": True,
      "data_processing_consent": True
    },
    "insurance_preferences": {
      "preferred_policy_types": [
        "Family Health",
        "Joint Life",
        "Home Insurance",
        "Travel Insurance"
      ],
      "coverage_priority": "Comprehensive Family Security"
    }
  },
  "risk_profile": {
    "risk_score": 41,
    "risk_category": "Moderate",
    "risk_factors": [
      "Home loan liability",
      "Spouse thyroid condition",
      "Moderate flood zone residence"
    ]
  }
}
,
 "USR200004":{
  "user_id": "USR200004",
  "personal_details": {
    "first_name": "Arjun",
    "last_name": "Mehta",
    "date_of_birth": "1985-01-18",
    "marital_status": "Married",
    "nationality": "Indian",
    "passport_number": "IND7788990",
    "residency_status": "UAE Work Visa",
    "contact_details": {
      "email": "arjun.mehta@email.com",
      "phone": "+971-501234567"
    },
    "address": {
      "street": "Marina Heights Tower",
      "city": "Dubai",
      "state": "Dubai",
      "pincode": "00000",
      "country": "UAE"
    },
    "kyc_status": "Verified",
    "created_at": "2025-01-05T07:20:00Z"
  },
  "travel_profile": {
    "frequent_flyer": True,
    "average_trips_per_year": 24,
    "primary_travel_regions": [
      "Europe",
      "USA",
      "South East Asia",
      "Middle East"
    ],
    "travel_type": "Business + Leisure",
    "airline_loyalty_programs": [
      "Emirates Skywards Platinum",
      "Lufthansa Miles & More"
    ],
    "longest_trip_duration_days": 45
  },
  "policies": [
    {
      "policy_id": "POL930401",
      "policy_type": "Global Travel Insurance",
      "plan_name": "Worldwide Executive Travel Shield",
      "sum_insured": 2000000,
      "premium_amount": 3500,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-02-01",
      "policy_end_date": "2026-01-31",
      "policy_status": "Active",
      "coverage_features": [
        "Medical Emergencies",
        "Trip Cancellation",
        "Flight Delay",
        "Baggage Loss",
        "Emergency Evacuation",
        "Pandemic Coverage"
      ],
      "nominees": [
        {
          "name": "Neha Mehta",
          "relationship": "Spouse",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM410678",
          "claim_type": "Flight Delay Compensation",
          "claim_amount": 450,
          "claim_status": "Settled",
          "claim_date": "2025-06-15",
          "incident_location": "Frankfurt Airport"
        }
      ]
    },
    {
      "policy_id": "POL930402",
      "policy_type": "International Health Insurance",
      "plan_name": "Global Expat Health Elite",
      "sum_insured": 1000000,
      "premium_amount": 4200,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-01-10",
      "policy_end_date": "2026-01-09",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Neha Mehta",
          "relationship": "Spouse",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM410890",
          "claim_type": "Hospitalization",
          "claim_amount": 5200,
          "claim_status": "Approved",
          "claim_date": "2025-09-03",
          "hospital_name": "Mount Elizabeth Hospital, Singapore"
        }
      ]
    },
    {
      "policy_id": "POL930403",
      "policy_type": "Life Insurance",
      "plan_name": "High Net Worth Term Cover",
      "sum_insured": 1500000,
      "premium_amount": 2600,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-03-01",
      "policy_end_date": "2055-02-28",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Neha Mehta",
          "relationship": "Spouse",
          "percentage_share": 70
        },
        {
          "name": "Rakesh Mehta",
          "relationship": "Father",
          "percentage_share": 30
        }
      ],
      "claims": []
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 200000,
      "occupation": "Senior Business Consultant",
      "employer": "Deloitte Middle East",
      "employment_type": "Salaried"
    },
    "payment_details": {
      "payment_method": "International Credit Card",
      "last_payment_date": "2025-03-01",
      "next_due_date": "2026-03-01",
      "auto_debit_enabled": True
    },
    "investment_profile": {
      "risk_appetite": "High",
      "existing_investments": [
        "Global Equity Funds",
        "Cryptocurrency",
        "Real Estate (India)",
        "Retirement Offshore Pension"
      ]
    },
    "liabilities": {
      "active_loans": [
        {
          "loan_type": "Luxury Apartment Loan",
          "outstanding_amount": 380000,
          "monthly_emi": 3500
        }
      ]
    }
  },
  "health_profile": {
    "height_cm": 177,
    "weight_kg": 79,
    "smoker": False,
    "alcohol_consumption": "Occasional",
    "exercise_frequency": "2_times_per_week",
    "pre_existing_conditions": [
      "Mild Cholesterol"
    ],
    "vaccination_status": [
      "COVID-19",
      "Yellow Fever",
      "Hepatitis B"
    ],
    "family_medical_history": [
      "Hypertension"
    ]
  },
  "lifestyle_profile": {
    "travel_frequency": "Very High",
    "hotel_stay_frequency": "Frequent",
    "hobbies": [
      "Golf",
      "Luxury Travel",
      "Networking Events"
    ],
    "work_style": "International Remote + Client Travel"
  },
  "assets": [
    {
      "asset_type": "Residential Apartment",
      "location": "Mumbai",
      "estimated_value": 750000
    },
    {
      "asset_type": "Luxury Car",
      "make_model": "BMW X5 2023",
      "estimated_value": 85000
    }
  ],
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Passport",
      "file_url": "https://storage.insurance.com/docs/passport_usr200004.pdf",
      "uploaded_at": "2025-01-05"
    },
    {
      "document_type": "Visa",
      "document_name": "UAE Work Visa",
      "file_url": "https://storage.insurance.com/docs/visa_usr200004.pdf",
      "uploaded_at": "2025-01-05"
    },
    {
      "document_type": "Income Proof",
      "document_name": "Employment Contract",
      "file_url": "https://storage.insurance.com/docs/contract_usr200004.pdf",
      "uploaded_at": "2025-01-06"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": True
    },
    "data_consent": {
      "marketing_consent": True,
      "data_processing_consent": True
    },
    "insurance_preferences": {
      "preferred_policy_types": [
        "Global Travel",
        "International Health",
        "High Value Life Cover",
        "Personal Accident Insurance"
      ],
      "coverage_priority": "Global Comprehensive Protection"
    }
  },
  "risk_profile": {
    "risk_score": 55,
    "risk_category": "Moderate to High",
    "risk_factors": [
      "Extensive international travel",
      "Frequent long-haul flights",
      "High value lifestyle assets",
      "Mild cholesterol condition"
    ]
  }
}
,
"USR200005":{
  "user_id": "USR200005",
  "personal_details": {
    "first_name": "Sophia",
    "last_name": "Clark",
    "date_of_birth": "1994-07-09",
    "marital_status": "UnMarried",
    "nationality": "American",
    "ssn_number": "XXX-XX-6721",
    "contact_details": {
      "email": "sophia.clark@email.com",
      "phone": "+1-5125553344"
    },
    "address": {
      "street": "742 Evergreen Terrace",
      "city": "Austin",
      "state": "Texas",
      "pincode": "73301",
      "country": "USA"
    },
    "kyc_status": "Verified",
    "created_at": "2025-04-02T11:25:00Z"
  },
  "pets": [
    {
      "pet_id": "PET001",
      "pet_name": "Buddy",
      "pet_type": "Dog",
      "breed": "Golden Retriever",
      "gender": "Male",
      "age": 4,
      "microchip_id": "MC998877665",
      "vaccination_status": [
        "Rabies",
        "Distemper",
        "Parvovirus"
      ],
      "pre_existing_conditions": [],
      "vet_details": {
        "vet_name": "Austin Pet Care",
        "last_visit_date": "2025-08-10"
      }
    }
  ],
  "policies": [
    {
      "policy_id": "POL940501",
      "policy_type": "Health Insurance",
      "plan_name": "US Comprehensive Health Gold",
      "sum_insured": 600000,
      "premium_amount": 2800,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-05-01",
      "policy_end_date": "2026-04-30",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Daniel Clark",
          "relationship": "Brother",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM510230",
          "claim_type": "Emergency Room Visit",
          "claim_amount": 1200,
          "claim_status": "Approved",
          "claim_date": "2025-09-21",
          "hospital_name": "St. David’s Medical Center"
        }
      ]
    },
    {
      "policy_id": "POL940502",
      "policy_type": "Life Insurance",
      "plan_name": "Young Achiever Term Plan",
      "sum_insured": 500000,
      "premium_amount": 900,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-06-01",
      "policy_end_date": "2055-05-31",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Daniel Clark",
          "relationship": "Brother",
          "percentage_share": 60
        },
        {
          "name": "Linda Clark",
          "relationship": "Mother",
          "percentage_share": 40
        }
      ],
      "claims": []
    },
    {
      "policy_id": "POL940503",
      "policy_type": "Pet Insurance",
      "plan_name": "Premium Pet Care Plus",
      "insured_pet_id": "PET001",
      "sum_insured": 20000,
      "premium_amount": 600,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-04-15",
      "policy_end_date": "2026-04-14",
      "policy_status": "Active",
      "coverage_features": [
        "Accident Coverage",
        "Illness Coverage",
        "Surgery",
        "Vaccination Reimbursement",
        "Annual Wellness Check"
      ],
      "claims": [
        {
          "claim_id": "CLM510890",
          "claim_type": "Minor Surgery",
          "claim_amount": 850,
          "claim_status": "Settled",
          "claim_date": "2025-07-12",
          "vet_clinic": "Austin Pet Care"
        }
      ]
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 72000,
      "occupation": "UX Designer",
      "employer": "Dell Technologies",
      "employment_type": "Salaried"
    },
    "payment_details": {
      "payment_method": "Debit Card",
      "last_payment_date": "2025-06-01",
      "next_due_date": "2026-06-01",
      "auto_debit_enabled": True
    },
    "investment_profile": {
      "risk_appetite": "Moderate",
      "existing_investments": [
        "Index Funds",
        "401(k) Retirement Plan"
      ]
    },
    "liabilities": {
      "active_loans": [
        {
          "loan_type": "Education Loan",
          "outstanding_amount": 24000,
          "monthly_emi": 420
        }
      ]
    }
  },
  "health_profile": {
    "height_cm": 167,
    "weight_kg": 64,
    "smoker": False,
    "alcohol_consumption": "Occasional",
    "exercise_frequency": "3_times_per_week",
    "pre_existing_conditions": [],
    "family_medical_history": [
      "Thyroid Disorder"
    ]
  },
  "lifestyle_profile": {
    "pet_owner": True,
    "travel_frequency": "Low",
    "hobbies": [
      "Dog Training",
      "Hiking",
      "Photography"
    ],
    "home_type": "Rented Apartment",
    "vehicle_owner": True
  },
  "assets": [
    {
      "asset_type": "Car",
      "make_model": "Honda Civic 2022",
      "estimated_value": 26000
    }
  ],
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Driving License",
      "file_url": "https://storage.insurance.com/docs/license_usr200005.pdf",
      "uploaded_at": "2025-04-02"
    },
    {
      "document_type": "Pet Registration",
      "document_name": "Pet Microchip Certificate",
      "file_url": "https://storage.insurance.com/docs/pet_usr200005.pdf",
      "uploaded_at": "2025-04-03"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": False
    },
    "data_consent": {
      "marketing_consent": True,
      "data_processing_consent": True
    },
    "insurance_preferences": {
      "preferred_policy_types": [
        "Health",
        "Pet Insurance",
        "Life Insurance",
        "Personal Accident"
      ],
      "coverage_priority": "Pet + Personal Protection"
    }
  },
  "risk_profile": {
    "risk_score": 36,
    "risk_category": "Low to Moderate",
    "risk_factors": [
      "Pet ownership liability",
      "Active outdoor lifestyle",
      "Education loan liability"
    ]
  }
},
"USR200006":{
  "user_id": "USR200006",
  "family_type": "Single_Parent",
  "personal_details": {
    "first_name": "Priya",
    "last_name": "Menon",
    "date_of_birth": "1989-03-15",
    "marital_status": "Divorced",
    "nationality": "Indian",
    "aadhaar_number": "XXXX-XXXX-8891",
    "pan_number": "PRMNM4582K",
    "contact_details": {
      "email": "priya.menon@email.com",
      "phone": "+91-9895123456"
    },
    "address": {
      "street": "Kowdiar Palace Road",
      "city": "Thiruvananthapuram",
      "state": "Kerala",
      "pincode": "695003",
      "country": "India"
    },
    "kyc_status": "Verified",
    "created_at": "2025-03-20T10:40:00Z"
  },
  "dependents": [
    {
      "dependent_id": "DEP001",
      "name": "Ananya Menon",
      "relationship": "Daughter",
      "gender": "Female",
      "date_of_birth": "2016-09-12",
      "schooling_status": "Primary School",
      "future_goals": "Higher Education Abroad"
    }
  ],
  "policies": [
    {
      "policy_id": "POL950601",
      "policy_type": "Health Insurance",
      "plan_name": "Family Floater Secure Plus",
      "covered_members": [
        "Priya Menon",
        "Ananya Menon"
      ],
      "sum_insured": 800000,
      "premium_amount": 18500,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-04-01",
      "policy_end_date": "2026-03-31",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Ananya Menon",
          "relationship": "Daughter",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM610245",
          "claim_type": "Pediatric Consultation",
          "claim_amount": 3200,
          "claim_status": "Approved",
          "claim_date": "2025-08-18",
          "hospital_name": "KIMS Hospital"
        }
      ]
    },
    {
      "policy_id": "POL950602",
      "policy_type": "Life Insurance",
      "plan_name": "Women Term Protection Plan",
      "sum_insured": 10000000,
      "premium_amount": 14500,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-05-01",
      "policy_end_date": "2055-04-30",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Ananya Menon",
          "relationship": "Daughter",
          "percentage_share": 100
        }
      ],
      "claims": []
    },
    {
      "policy_id": "POL950603",
      "policy_type": "Child Education Insurance",
      "plan_name": "Future Scholar Child Plan",
      "insured_child": "Ananya Menon",
      "maturity_year": 2034,
      "sum_assured": 2500000,
      "annual_premium": 60000,
      "policy_start_date": "2025-06-01",
      "policy_status": "Active",
      "benefits": [
        "Guaranteed Maturity Payout",
        "Waiver of Premium on Parent Death",
        "Education Milestone Payments"
      ],
      "claims": []
    },
    {
      "policy_id": "POL950604",
      "policy_type": "Personal Accident Insurance",
      "plan_name": "Income Protection Accident Shield",
      "sum_insured": 3000000,
      "premium_amount": 4200,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-05-15",
      "policy_end_date": "2026-05-14",
      "policy_status": "Active",
      "claims": []
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 650000,
      "occupation": "Higher Secondary School Teacher",
      "employer": "St. Mary's Higher Secondary School",
      "employment_type": "Salaried"
    },
    "payment_details": {
      "payment_method": "UPI",
      "last_payment_date": "2025-06-01",
      "next_due_date": "2026-06-01",
      "auto_debit_enabled": True
    },
    "investment_profile": {
      "risk_appetite": "Moderate",
      "existing_investments": [
        "Public Provident Fund (PPF)",
        "SIP Mutual Funds",
        "Fixed Deposits"
      ]
    },
    "liabilities": {
      "active_loans": [
        {
          "loan_type": "Home Loan",
          "outstanding_amount": 2800000,
          "monthly_emi": 26000
        }
      ]
    },
    "monthly_expense_breakdown": {
      "household_expenses": 25000,
      "child_education": 12000,
      "loan_emi": 26000,
      "insurance_premium_allocation": 9000
    }
  },
  "health_profile": {
    "height_cm": 160,
    "weight_kg": 59,
    "smoker": False,
    "alcohol_consumption": "None",
    "exercise_frequency": "2_times_per_week",
    "pre_existing_conditions": [
      "Mild Thyroid"
    ],
    "family_medical_history": [
      "Diabetes"
    ]
  },
  "dependent_health_profile": [
    {
      "name": "Ananya Menon",
      "vaccination_status": "Fully Vaccinated",
      "chronic_conditions": []
    }
  ],
  "lifestyle_profile": {
    "single_income_household": True,
    "travel_frequency": "Low",
    "hobbies": [
      "Reading",
      "Classical Dance",
      "Cooking"
    ],
    "home_owner": True,
    "financial_dependents_count": 1
  },
  "assets": [
    {
      "asset_type": "Residential House",
      "estimated_value": 5200000
    },
    {
      "asset_type": "Two Wheeler",
      "make_model": "Honda Activa 2022",
      "estimated_value": 90000
    }
  ],
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Aadhaar Card",
      "file_url": "https://storage.insurance.com/docs/aadhaar_usr200006.pdf",
      "uploaded_at": "2025-03-20"
    },
    {
      "document_type": "Income Proof",
      "document_name": "Salary Certificate",
      "file_url": "https://storage.insurance.com/docs/salary_usr200006.pdf",
      "uploaded_at": "2025-03-21"
    },
    {
      "document_type": "Child Birth Certificate",
      "document_name": "Birth Certificate - Ananya",
      "file_url": "https://storage.insurance.com/docs/birth_usr200006.pdf",
      "uploaded_at": "2025-03-21"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": True
    },
    "data_consent": {
      "marketing_consent": False,
      "data_processing_consent": True
    },
    "insurance_preferences": {
      "preferred_policy_types": [
        "Child Education",
        "Life Insurance",
        "Family Health",
        "Income Protection"
      ],
      "coverage_priority": "Child Financial Security"
    }
  },
  "risk_profile": {
    "risk_score": 63,
    "risk_category": "Moderate to High",
    "risk_factors": [
      "Single income household",
      "Dependent child",
      "Outstanding home loan",
      "Mild thyroid condition"
    ]
  }
}
,
"USR774512":{
  "user_id": "USR774512",
  "personal_details": {
    "first_name": "Rohan",
    "last_name": "Mehta",
    "date_of_birth": "1992-11-22",
    "gender": "Male",
    "marital_status": "UnMarried",
    "nationality": "Indian",
    "aadhaar_number": "XXXX-XXXX-7745",
    "pan_number": "RMHTA4521K",
    "contact_details": {
      "email": "rohan.mehta@email.com",
      "phone": "+91-9123456780"
    },
    "address": {
      "street": "Satellite Road",
      "city": "Ahmedabad",
      "state": "Gujarat",
      "pincode": "380015",
      "country": "India"
    },
    "kyc_status": "Verified",
    "created_at": "2024-12-18T09:45:00Z"
  },
  "policies": [
    {
      "policy_id": "POL884421",
      "policy_type": "Health Insurance",
      "plan_name": "Special Care Health Shield",
      "sum_insured": 1500000,
      "premium_amount": 18500,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-01-10",
      "policy_end_date": "2026-01-09",
      "policy_status": "Active",
      "coverage_details": {
        "covers_disability_related_treatments": True,
        "rehabilitation_coverage": True,
        "prosthetic_coverage": True,
        "home_nursing": True
      },
      "nominees": [
        {
          "name": "Suresh Mehta",
          "relationship": "Father",
          "percentage_share": 50
        },
        {
          "name": "Kavita Mehta",
          "relationship": "Mother",
          "percentage_share": 50
        }
      ],
      "claims": [
        {
          "claim_id": "CLM77451",
          "claim_type": "Physiotherapy",
          "claim_amount": 32000,
          "claim_status": "Approved",
          "claim_date": "2025-06-20",
          "hospital_name": "Apollo Rehabilitation Centre"
        }
      ]
    },
    {
      "policy_id": "POL884422",
      "policy_type": "Personal Accident Insurance",
      "plan_name": "Comprehensive Disability Cover",
      "sum_insured": 2500000,
      "premium_amount": 9500,
      "premium_frequency": "Yearly",
      "policy_start_date": "2025-01-10",
      "policy_end_date": "2026-01-09",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Suresh Mehta",
          "relationship": "Father",
          "percentage_share": 100
        }
      ],
      "claims": []
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 720000,
      "occupation": "UI/UX Designer",
      "employer": "Freelancer",
      "employment_type": "Self-Employed"
    },
    "payment_details": {
      "payment_method": "Net Banking",
      "last_payment_date": "2025-01-10",
      "next_due_date": "2026-01-10",
      "auto_debit_enabled": True
    },
    "government_benefits": {
      "disability_pension": True,
      "monthly_benefit_amount": 6000,
      "benefit_provider": "Government of India"
    }
  },
  "health_profile": {
    "height_cm": 170,
    "weight_kg": 72,
    "smoker": False,
    "alcohol_consumption": "No",
    "disability_details": {
      "disability_type": "Lower Limb Mobility Impairment",
      "disability_percentage": 55,
      "assistive_devices_used": [
        "Wheelchair"
      ],
      "requires_regular_therapy": True
    },
    "pre_existing_conditions": [
      "Post Spinal Injury Mobility Limitation"
    ],
    "family_medical_history": [
      "Hypertension"
    ]
  },
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Aadhaar Card",
      "file_url": "https://storage.insurance.com/docs/aadhaar_usr774512.pdf",
      "uploaded_at": "2024-12-18"
    },
    {
      "document_type": "Disability Certificate",
      "document_name": "Government Disability Certificate",
      "file_url": "https://storage.insurance.com/docs/disability_usr774512.pdf",
      "uploaded_at": "2024-12-18"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": True
    },
    "accessibility_preferences": {
      "requires_voice_support": True,
      "large_text_interface": True
    },
    "data_consent": {
      "marketing_consent": False,
      "data_processing_consent": True
    }
  }
}
,
"USR889631":{
  "user_id": "USR889631",
  "personal_details": {
    "first_name": "Arjun",
    "last_name": "Rathore",
    "date_of_birth": "1988-03-09",
    "gender": "Male",
    "marital_status": "Married",
    "nationality": "Indian",
    "aadhaar_number": "XXXX-XXXX-8896",
    "pan_number": "ARJRT9631H",
    "contact_details": {
      "email": "arjun.rathore@email.com",
      "phone": "+91-9012345678"
    },
    "address": {
      "street": "Defence Colony",
      "city": "Jaipur",
      "state": "Rajasthan",
      "pincode": "302018",
      "country": "India"
    },
    "kyc_status": "Verified",
    "created_at": "2024-08-05T07:20:00Z"
  },
  "military_details": {
    "service_branch": "Indian Army",
    "rank": "Major",
    "service_number": "IA-458963",
    "years_of_service": 14,
    "active_duty": True,
    "deployment_history": [
      {
        "location": "Ladakh",
        "deployment_type": "Border Security",
        "start_date": "2022-05-01",
        "end_date": "2023-01-30"
      },
      {
        "location": "UN Peacekeeping - Congo",
        "deployment_type": "International Mission",
        "start_date": "2020-02-15",
        "end_date": "2021-01-20"
      }
    ],
    "risk_category": "High Risk Duty"
  },
  "policies": [
    {
      "policy_id": "POL998871",
      "policy_type": "Life Insurance",
      "plan_name": "Defence Term Protection Plan",
      "sum_insured": 5000000,
      "premium_amount": 22000,
      "premium_frequency": "Yearly",
      "policy_start_date": "2024-09-01",
      "policy_end_date": "2044-08-31",
      "policy_status": "Active",
      "coverage_details": {
        "war_zone_coverage": True,
        "accidental_death_multiplier": 2,
        "disability_cover": True
      },
      "nominees": [
        {
          "name": "Priya Rathore",
          "relationship": "Spouse",
          "percentage_share": 70
        },
        {
          "name": "Kabir Rathore",
          "relationship": "Son",
          "percentage_share": 30
        }
      ],
      "claims": []
    },
    {
      "policy_id": "POL998872",
      "policy_type": "Health Insurance",
      "plan_name": "Armed Forces Family Health Cover",
      "sum_insured": 2000000,
      "premium_amount": 18000,
      "premium_frequency": "Yearly",
      "policy_start_date": "2024-09-01",
      "policy_end_date": "2025-08-31",
      "policy_status": "Active",
      "coverage_details": {
        "cashless_military_hospitals": True,
        "family_floater": True,
        "air_ambulance": True
      },
      "insured_members": [
        "Arjun Rathore",
        "Priya Rathore",
        "Kabir Rathore"
      ],
      "nominees": [
        {
          "name": "Priya Rathore",
          "relationship": "Spouse",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM99871",
          "claim_type": "Child Hospitalization",
          "claim_amount": 68000,
          "claim_status": "Approved",
          "claim_date": "2025-02-14",
          "hospital_name": "Command Hospital Jaipur"
        }
      ]
    },
    {
      "policy_id": "POL998873",
      "policy_type": "Personal Accident Insurance",
      "plan_name": "Combat Injury Shield",
      "sum_insured": 3000000,
      "premium_amount": 7500,
      "premium_frequency": "Yearly",
      "policy_start_date": "2024-09-01",
      "policy_end_date": "2025-08-31",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Priya Rathore",
          "relationship": "Spouse",
          "percentage_share": 100
        }
      ],
      "claims": []
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 1400000,
      "occupation": "Military Officer",
      "employer": "Indian Army",
      "employment_type": "Government"
    },
    "allowances": {
      "risk_allowance": 25000,
      "housing_allowance": 35000,
      "field_allowance": 18000
    },
    "payment_details": {
      "payment_method": "Salary Deduction",
      "last_payment_date": "2024-09-01",
      "next_due_date": "2025-09-01",
      "auto_debit_enabled": True
    }
  },
  "health_profile": {
    "height_cm": 178,
    "weight_kg": 82,
    "smoker": False,
    "alcohol_consumption": "Occasional",
    "fitness_level": "High",
    "service_related_injuries": [],
    "pre_existing_conditions": [],
    "family_medical_history": [
      "Heart Disease"
    ]
  },
  "family_details": {
    "spouse": {
      "name": "Priya Rathore",
      "date_of_birth": "1991-07-19",
      "occupation": "Teacher"
    },
    "children": [
      {
        "name": "Kabir Rathore",
        "date_of_birth": "2018-04-10",
        "gender": "Male"
      }
    ]
  },
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Aadhaar Card",
      "file_url": "https://storage.insurance.com/docs/aadhaar_usr889631.pdf",
      "uploaded_at": "2024-08-05"
    },
    {
      "document_type": "Service ID",
      "document_name": "Military Service Card",
      "file_url": "https://storage.insurance.com/docs/service_usr889631.pdf",
      "uploaded_at": "2024-08-05"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": True,
      "sms_notifications": True,
      "whatsapp_notifications": False
    },
    "deployment_mode_contact": {
      "primary_contact_person": "Priya Rathore",
      "relationship": "Spouse",
      "contact_number": "+91-9876501234"
    },
    "data_consent": {
      "marketing_consent": False,
      "data_processing_consent": True
    }
  }
}
,
"USR990214":{
  "user_id": "USR990214",
  "personal_details": {
    "first_name": "Krishnan",
    "last_name": "Menon",
    "date_of_birth": "1954-01-17",
    "gender": "Male",
    "marital_status": "Married",
    "nationality": "Indian",
    "aadhaar_number": "XXXX-XXXX-9902",
    "pan_number": "KRMEN0214D",
    "contact_details": {
      "email": "krishnan.menon@email.com",
      "phone": "+91-9447012345"
    },
    "address": {
      "street": "Panampilly Nagar",
      "city": "Kochi",
      "state": "Kerala",
      "pincode": "682036",
      "country": "India"
    },
    "kyc_status": "Verified",
    "created_at": "2023-05-14T08:30:00Z"
  },
  "retirement_details": {
    "retirement_status": "Retired",
    "former_occupation": "Bank Manager",
    "former_employer": "State Bank of India",
    "retirement_year": 2014,
    "pension_type": "Government Pension",
    "monthly_pension_amount": 52000
  },
  "policies": [
    {
      "policy_id": "POL667890",
      "policy_type": "Senior Citizen Health Insurance",
      "plan_name": "Golden Years Health Protect",
      "sum_insured": 1200000,
      "premium_amount": 42000,
      "premium_frequency": "Yearly",
      "policy_start_date": "2024-06-01",
      "policy_end_date": "2025-05-31",
      "policy_status": "Active",
      "coverage_details": {
        "pre_existing_disease_cover": True,
        "annual_health_checkup": True,
        "domiciliary_treatment": True,
        "critical_illness_addon": True
      },
      "nominees": [
        {
          "name": "Lakshmi Menon",
          "relationship": "Spouse",
          "percentage_share": 100
        }
      ],
      "claims": [
        {
          "claim_id": "CLM66789",
          "claim_type": "Cardiac Treatment",
          "claim_amount": 210000,
          "claim_status": "Approved",
          "claim_date": "2024-11-18",
          "hospital_name": "Lakeshore Hospital Kochi"
        }
      ]
    },
    {
      "policy_id": "POL667891",
      "policy_type": "Life Insurance",
      "plan_name": "Whole Life Senior Assurance",
      "sum_insured": 1500000,
      "premium_amount": 18000,
      "premium_frequency": "Yearly",
      "policy_start_date": "2018-03-15",
      "policy_end_date": "Lifetime",
      "policy_status": "Active",
      "nominees": [
        {
          "name": "Lakshmi Menon",
          "relationship": "Spouse",
          "percentage_share": 60
        },
        {
          "name": "Rahul Menon",
          "relationship": "Son",
          "percentage_share": 40
        }
      ],
      "claims": []
    }
  ],
  "financial_details": {
    "income_details": {
      "annual_income": 624000,
      "income_source": [
        "Government Pension",
        "Fixed Deposit Interest"
      ]
    },
    "investment_details": {
      "fixed_deposits": 1500000,
      "mutual_funds": 450000,
      "senior_citizen_savings_scheme": 900000
    },
    "payment_details": {
      "payment_method": "Net Banking",
      "last_payment_date": "2024-06-01",
      "next_due_date": "2025-06-01",
      "auto_debit_enabled": True
    }
  },
  "health_profile": {
    "height_cm": 168,
    "weight_kg": 74,
    "smoker": False,
    "alcohol_consumption": "No",
    "mobility_status": "Moderate",
    "pre_existing_conditions": [
      "Type 2 Diabetes",
      "Coronary Artery Disease",
      "Hypertension"
    ],
    "regular_medications": [
      "Insulin",
      "Blood Pressure Medication",
      "Blood Thinners"
    ],
    "family_medical_history": [
      "Stroke",
      "Heart Disease"
    ],
    "last_health_checkup": "2025-01-10"
  },
  "family_details": {
    "spouse": {
      "name": "Lakshmi Menon",
      "date_of_birth": "1958-09-21",
      "occupation": "Homemaker"
    },
    "children": [
      {
        "name": "Rahul Menon",
        "date_of_birth": "1985-07-03",
        "occupation": "Chartered Accountant",
        "city": "Bangalore"
      }
    ]
  },
  "documents": [
    {
      "document_type": "KYC",
      "document_name": "Aadhaar Card",
      "file_url": "https://storage.insurance.com/docs/aadhaar_usr990214.pdf",
      "uploaded_at": "2023-05-14"
    },
    {
      "document_type": "Pension Certificate",
      "document_name": "Retirement Pension Proof",
      "file_url": "https://storage.insurance.com/docs/pension_usr990214.pdf",
      "uploaded_at": "2023-05-14"
    },
    {
      "document_type": "Medical Records",
      "document_name": "Cardiac Treatment Reports",
      "file_url": "https://storage.insurance.com/docs/medical_usr990214.pdf",
      "uploaded_at": "2024-11-25"
    }
  ],
  "preferences": {
    "communication_preferences": {
      "email_notifications": False,
      "sms_notifications": True,
      "whatsapp_notifications": True
    },
    "care_preferences": {
      "home_healthcare_required": True,
      "emergency_contact": {
        "name": "Rahul Menon",
        "relationship": "Son",
        "phone": "+91-9887766554"
      }
    },
    "data_consent": {
      "marketing_consent": False,
      "data_processing_consent": True
    }
  }
}
}