import json
import os
from datetime import datetime, timedelta
from dotenv import load_dotenv
from langchain_groq import ChatGroq
import httpx

from services.user_service import UserService
from services.policy_service import PolicyService
from services.news_service import NewsService

load_dotenv()

# =========================
# 🔐 LLM CONFIGURATION
# =========================
client = httpx.Client(verify=False)

llm = ChatGroq(
    model="llama-3.3-70b-versatile",
    api_key=os.getenv("GROQ_API_KEY"),
    temperature=0,
    http_client=client
)


# =========================
# 🎯 MAIN FUNCTION
# =========================
def generate_recommendation(user_id: str):

    # -----------------------------
    # STEP 1 → Fetch User Data
    # -----------------------------
    user_data = UserService.fetch_user(user_id)
    if not user_data or "error" in user_data:
        return {"error": "User not found or invalid user data"}

    user_age = user_data.get("age", 0)
    user_policies = user_data.get("policies", [])
    active_policy_ids = [p.get("policy_id") for p in user_policies]

    # -----------------------------
    # STEP 2 → Fetch News & Risk Signals
    # -----------------------------
    news_articles = NewsService.fetch_news()
    if isinstance(news_articles, dict) and "error" in news_articles:
        return news_articles

    risk_signals = NewsService.extract_risk_signals(user_data, news_articles)
    category_boosts = NewsService.map_risk_to_category_boost(risk_signals)

    # -----------------------------
    # STEP 3 → Fetch Policies
    # -----------------------------
    policies = PolicyService.fetch_policies()
    if isinstance(policies, dict) and "error" in policies:
        return policies

    # -----------------------------
    # STEP 4 → Layering + Scoring
    # -----------------------------
    today = datetime.today()
    expiry_threshold = today + timedelta(days=30)

    layer_1_new_high_priority = []
    layer_2_expiring_or_upgrade = []
    layer_3_not_eligible = []

    for policy in policies:
        policy_copy = policy.copy()
        policy_id = policy_copy.get("productId") or policy_copy.get("policy_id")
        category = policy_copy.get("category", "General")
        eligibility = policy_copy.get("eligibility", {})

        min_age = eligibility.get("min_age", 0)
        max_age = eligibility.get("max_age", 100)

        # ACTIVE POLICY → Expiry Check
        if policy_id in active_policy_ids:
            for user_policy in user_policies:
                if user_policy.get("policy_id") == policy_id:
                    expiry_date_str = user_policy.get("expiry_date")
                    if expiry_date_str:
                        try:
                            expiry_date = datetime.strptime(expiry_date_str, "%Y-%m-%d")
                            if expiry_date <= expiry_threshold:
                                layer_2_expiring_or_upgrade.append(policy_copy)
                        except Exception:
                            pass
        # NEW POLICY → Eligibility
        else:
            if min_age <= user_age <= max_age:
                boost_score = category_boosts.get(category, 0)
                policy_copy["boost_score"] = boost_score
                layer_1_new_high_priority.append(policy_copy)
            else:
                layer_3_not_eligible.append(policy_copy)

    # Sort Layer 1 by Boost Score
    layer_1_new_high_priority.sort(key=lambda x: x.get("boost_score", 0), reverse=True)

    # Ensure at least some policies exist
    if not layer_1_new_high_priority and not layer_2_expiring_or_upgrade:
        return {"error": "No eligible policies available for recommendation"}

    structured_context = {
        "layer_1_new_high_priority": layer_1_new_high_priority,
        "layer_2_expiring_or_upgrade": layer_2_expiring_or_upgrade,
        "layer_3_not_eligible": layer_3_not_eligible,
        "risk_signals": risk_signals,
        "category_boosts": category_boosts
    }

    # -----------------------------
    # STEP 5 → LLM Prompt
    # -----------------------------
    prompt = f"""
You are an AI-powered Smart Insurance Recommendation Engine.

PRIORITY ORDER:
1) Recommend from layer_1_new_high_priority first (highest boost_score first).
2) Then recommend from layer_2_expiring_or_upgrade.
3) Use layer_3_not_eligible only if necessary.

You MUST recommend at least FIVE policies.

For each recommended policy:
- Provide a short, professional reasoning referencing:
    • User age OR
    • Risk signals OR
    • Expiry logic OR
    • Category boost logic

STRICT RULES:
- Only use policy_id values from structured data.
- Output ONLY valid JSON.
- No markdown or extra text.

STRUCTURED DATA:
{json.dumps(structured_context)}

OUTPUT FORMAT:
{{
  "user_id": "{user_id}",
  "recommendation": {{
    "recommended_policy_ids": ["POLICY_ID_1", "POLICY_ID_2", "POLICY_ID_3", "POLICY_ID_4", "POLICY_ID_5" ],
    "reasoning": {{
      "POLICY_ID_1": "Short reason",
      "POLICY_ID_2": "Short reason",
      "POLICY_ID_3": "Short reason",
      "POLICY_ID_4": "Short reason",
      "POLICY_ID_5": "Short reason"
    }}
  }}
}}
"""

    # -----------------------------
    # STEP 6 → LLM Call & Safe JSON Parsing
    # -----------------------------
    try:
        response = llm.invoke(prompt)
        cleaned = response.content.strip()

        # Remove accidental markdown if present
        if cleaned.startswith("```"):
            cleaned = cleaned.split("```")[1]

        return json.loads(cleaned)

    except Exception:
        return {
            "error": "Invalid JSON returned by LLM",
            "raw_response": response.content if "response" in locals() else ""
        }
