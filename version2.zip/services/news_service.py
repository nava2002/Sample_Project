import os
import json


class NewsService:

    @staticmethod
    def fetch_news(location: str) -> dict:
        """
        Fetch user data from local JSON file
        """

        try:
            with open("data/news.json", "r") as f:
                news = json.load(f)

            # Assuming JSON contains list of news
            print(news)
            # raw_user = next(
            #     (user for user in news if str(user.get("user_id")) == str(user_id)),
            #     None
            # )

            # if not raw_user:
            #     return {
            #         "error": "User not found",
            #         "user_id": user_id
            #     }

            # return newservice._normalize_user(raw_user)
            return news

        except Exception as e:
            return {
                "error": str(e),
                
            }

    # @staticmethod
    # def _normalize_user(raw_user: dict) -> dict:
    #     """
    #     Normalize local JSON data to internal insurance format
    #     """

    #     return {
    #         "user_id": raw_user.get("user_id"),
    #         "name": f"{raw_user.get('personal_details', {}).get('first_name', '')} "
    #                 f"{raw_user.get('personal_details', {}).get('last_name', '')}".strip(),
    #         "email": raw_user.get("personal_details", {}).get("contact_details", {}).get("email"),
    #         "location": raw_user.get("personal_details", {}).get("address", {}).get("city"),
    #         "phone": raw_user.get("personal_details", {}).get("contact_details", {}).get("phone"),
    #         "policies": raw_user.get("policies", [])
    #     }
