from langchain_groq import ChatGroq
import json
# from services.news_service import get_news
from services.user_service import UserService
from services.policy_service import PolicyService
from services.news_service import NewsService

from tools.user_tool import fetch_user_data
from tools.news_tool import fetch_location_news
from tools.policy_tool import fetch_company_policies




# ✅ Groq LLM
llm = ChatGroq(
    model="llama-3.3-70b-versatile",   # Best general Groq model
    api_key="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",
    temperature=0
)


def generate_recommendation(user_id: str):

    # ------------------------
    # STEP 1 → Fetch User Data
    # ------------------------
    user_data = UserService.fetch_user(user_id)

    if "error" in user_data:
        return user_data

    location = user_data.get("location")


    # ------------------------
    # STEP 2 → Fetch News
    # ------------------------
    news_data = NewsService.fetch_news(location)
    print("Fetched News:", news_data)


    # ------------------------
    # STEP 3 → Fetch Policies
    # ------------------------
    # policies = fetch_company_policies()
    policies = PolicyService.fetch_policy()
    print("Fetched Policies:", policies)


    # ------------------------
    # STEP 4 → Send Final Context To LLM
    # ------------------------
    prompt = f"""
You are an AI-powered Smart Insurance Recommendation Engine.

Use ONLY the provided data to recommend policies.

USER DATA:
{json.dumps(user_data, indent=2)}

LOCATION RISK NEWS:
{json.dumps(news_data, indent=2)}


AVAILABLE POLICIES:
{json.dumps(policies, indent=2)}



RULES:

- Recommend at least THREE policies.
- Only use policy IDs present in AVAILABLE POLICIES.
- Do not explain reasoning.
- Output ONLY valid JSON.

FORMAT:
{{
  "recommended_policy_ids": [
    "POLICY_ID_1",
    "POLICY_ID_2"
  ]
}}

REASONING:
- Explain the reasoning for the recommended policies with news title used.
- Explain the reasoning for the recommended policies with news title used for the recommendation.
FORMAT:
{{
  "reasoning": "Reasoning for the recommended policies with news title used for the recommendation"
}}

"""
    print("Prompt:", prompt)
    response = llm.invoke(prompt)

    return response
