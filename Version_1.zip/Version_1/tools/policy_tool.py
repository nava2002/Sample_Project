import json
from langchain.tools import tool

@tool
def fetch_company_policies():
    """Fetch available insurance schemes"""
    
    with open("data/policies.json") as f:
        return json.load(f)
