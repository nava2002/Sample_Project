from langchain.tools import tool
from services.news_service import get_news

@tool
def fetch_location_news(location: str):
    """Fetch latest news related to user's location"""
    return get_news(location)
