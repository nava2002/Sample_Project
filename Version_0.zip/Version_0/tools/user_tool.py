from langchain.tools import tool

# Simulated DB
USER_DB = {
    "101": {
        "name": "Rahul",
        "age": 35,
        "income": 900000,
        "location": "Mumbai",
        "dependents": 2,
        "risk_profile": "MEDIUM"
    }
}

@tool
def fetch_user_data(user_id: str) -> dict:
    """Fetch user insurance profile data"""
    return USER_DB.get(user_id, {})
