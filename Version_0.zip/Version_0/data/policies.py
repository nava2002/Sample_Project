[
  {
    "name": "Family Health Shield",
    "type": "Health",
    "target": "Families",
    "min_age": 25
  },
  {
    "name": "Senior Secure Plan",
    "type": "Health",
    "target": "Senior Citizens",
    "min_age": 55
  },
  {
    "name": "Income Guard Policy",
    "type": "Life",
    "target": "Working Professionals",
    "min_income": 500000
  }
]
