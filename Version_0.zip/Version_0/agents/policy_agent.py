from langchain_ollama import ChatOllama
from langchain.agents import create_agent

from tools.user_tool import fetch_user_data
from tools.news_tool import fetch_location_news
from tools.policy_tool import fetch_company_policies


# 👇 Replace OpenAI with Ollama
llm = ChatOllama(
    model="llama-3.2-3b-it:latest",   # change if using another model
    temperature=0
)


tools = [
    fetch_user_data,
    fetch_location_news,
    fetch_company_policies
]


agent = create_agent(
    model=llm,
    tools=tools,
    system_prompt="""
You are an insurance advisor AI.

Steps:
1. Fetch user data using user_id
2. Use location from user data to fetch news
3. Fetch company policies
4. Recommend best policies based on:
   - user profile
   - dependents
   - income
   - risk profile
   - location news

Provide structured recommendation.
"""
)


def generate_recommendation(user_id: str):

    response = agent.invoke({
        "messages": [
            {
                "role": "user",
                "content": f"Generate recommendation for user_id: {user_id}"
            }
        ]
    })

    return response
