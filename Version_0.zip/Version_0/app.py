from fastapi import FastAPI
from agents.policy_agent import generate_recommendation

app = FastAPI()


@app.post("/recommend-policy/{user_id}")
def recommend_policy(user_id: str):

    result = generate_recommendation(user_id)

    return {
        "user_id": user_id,
        "recommendation": result
    }
