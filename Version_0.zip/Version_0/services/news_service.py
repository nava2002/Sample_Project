import requests
import os

NEWS_API_KEY = os.getenv("NEWS_API_KEY")

def get_news(location: str):
    url = f"https://newsapi.org/v2/everything?q={location}&apiKey={NEWS_API_KEY}"
    
    res = requests.get(url)
    articles = res.json().get("articles", [])

    return [a["title"] for a in articles[:5]]
